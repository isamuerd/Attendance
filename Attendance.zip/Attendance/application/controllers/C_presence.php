<?php
	/*
	presence controller
	Author Eka Erdiansyah
	*/
	
	class C_presence extends CI_Controller{
		function __construct(){
			parent::__construct();
		}
		
		function index(){
			$this->load->view("presence/index");
		}
		
		function presence(){
			$this->load->view("presence");
		}
		
		function recapPresence(){
			$this->load->view("presence/recap_presence");
		}
	}
?>